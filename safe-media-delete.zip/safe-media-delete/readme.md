# Safe Media Delete

**Contributors:** Robert Granlund
**Tags:** safe media delete
**Requires at least:** WordPress 5.0
**Tested up to:** 6.1
**Stable tag:** 1.0.0
**License:** GPLv2 or later
**License URI:** https://www.gnu.org/licenses/gpl-2.0.html

## Description

This plugin supplies the following functionality:

1.  Ability to add an Image to a Term
2.  This plugin disables the ability to permanently delete an image from the Media Library if the image is associated with a Page, Post or Term.
3.  Lists all of the Pages, Posts and Terms an image is associated with on the Media Library page.
4.  Lists all of the Pages, Posts and Terms an image is associated with on the Attachment Details page.
5.  Along with the Image details, a link to all corresponding Post, Page or Terms are supplied and color coded for differentiation.

## Installation

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Additional Developer Notes can be found in the plugin root directory developer-notes.md

## Frequently Asked Questions

1. How do I know if an image is associated with a Post, Page or Term?
   There is an Image Warning displayed with the Image details.

2. How can I tell the difference between what type of Post, Page or Term the image is associated with?
   The associated Post, Page or Term link are identified by the corresponding post, page or term type and are color coded on :hover.

3. How do I know that the image was not deleted when "Permanently Delete" is clicked?
   An Alert will display a message that the image has not been deleted.

4. How do I know that the image has been deleted when "Permanently Delete" is clicked?
   The delete functionality will happen as normal.

## Changelog

### 1.0.0

- Initial release

## Upgrade Notice

### 1.0.0

- This is the first version of the plugin
