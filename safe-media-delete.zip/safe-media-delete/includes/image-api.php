<?php
// Registering the REST API endpoint
add_action('rest_api_init', 'register_image_details_endpoint');
function register_image_details_endpoint() {
    register_rest_route('assignment/v1', '/image/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'get_image_details',
        'args' => array(
            'id' => array(
                'required' => true,
                'description' => 'This is the ID of the Attached Image'
            )
        )
    ));
}

// This is the Callback function to retrieve image details
function get_image_details($request) {
    $image_id = $request->get_param('id');
    $image_data = array();

    // Get image details
    $attachment = get_post($image_id);
    if ($attachment && $attachment->post_type === 'attachment' && $attachment->post_mime_type !== 'image/svg+xml') {
        $image_data['ID'] = $attachment->ID;
        $image_data['Date'] = $attachment->post_date;
        $image_data['Slug'] = $attachment->post_name;
        $image_data['Type'] = $attachment->post_mime_type;
        $image_data['Link'] = wp_get_attachment_url($attachment->ID);
        $image_data['Alt text'] = get_post_meta($attachment->ID, '_wp_attachment_image_alt', true);

        // Get attached post IDs
        $attached_posts = get_posts(array(
            'post_type' => 'any',
            'post_status' => 'any',
            'fields' => 'ids',
            'meta_query' => array(
                array(
                    'key' => '_thumbnail_id',
                    'value' => $attachment->ID,
                    'compare' => '='
                )
            )
        ));
        if ($attached_posts) {
            //$attached_post_ids = wp_list_pluck($attached_posts, 'ID');
            $attached_post_ids = array_map( function( $post ) {
                return $post;
             }, $attached_posts );
            $image_data['Attached Objects']['Post(s) Featured Image'] = $attached_post_ids;
        }


        // Check if attachment is included in post content
$post_containing_image = get_posts(array(
    's' => $attachment->ID,
    'post_type' => array('post', 'page'),
    'post_status' => 'any',
    'fields' => 'ids',
    ));
    if ($post_containing_image) {
        //$attached_post_ids = wp_list_pluck($attached_posts, 'ID');
        $pci = array_map( function( $post ) {
            return $post;
         }, $post_containing_image);
        $image_data['Attached Objects']['Included In Post(s)'] = $pci;
    }

        // Get attached term IDs
            global $wpdb;

            $terms = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT term_id FROM $wpdb->termmeta WHERE meta_key = 'taxonomy_image_id' AND meta_value = %s",
                    $attachment->ID
                )
            );
            
            $term_ids = array();
            foreach ($terms as $term) {
                $term_ids[] = $term->term_id;
            }
            if($term_ids) {
            $image_data['Attached Objects']['Term(s)'] = $term_ids;
            }
        }  

    // Return the image data as a JSON response
    return rest_ensure_response($image_data);
}


?>