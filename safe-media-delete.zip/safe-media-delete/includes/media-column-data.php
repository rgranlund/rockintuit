<?php

// Add "Attached Objects" column to Media Library table
function add_attached_objects_column($columns)
{
    $columns['attached_objects'] = 'Attached Objects';
    return $columns;
}
add_filter('manage_media_columns', 'add_attached_objects_column');

// Populate "Attached Objects" column with data
function populate_attached_objects_column($column_name, $attachment_id)
{
    if ($column_name === 'attached_objects') {


        $attached_objects = get_attached_objects_alt($attachment_id);
        $output = '';

        if($attached_objects) {

            $output .='<div class="linked-title">Linked Article(s) for Img: '.$attachment_id.'</div>';
            foreach ($attached_objects as $object) {
                $object_type = '';
                if ($object->post_type) {
                    $p_type = $object->post_type;
                    if ($p_type == "post") {
                        $object_type = 'Post';
                    } elseif ($p_type == "page") {
                        $object_type = 'Page';
                    }
                    $output .= '<div class="link-cont"><a target="_blank" class="smd-link '.$p_type.'-link" href="' . get_edit_post_link($object->ID) . '">' . $object_type . ' ID:' . $object->ID . '</a></div>';
                } elseif ($object->taxonomy) {
                    $object_type = 'Term';
                    $term_id = $object->term_id;

                    $taxonomy = $object->taxonomy;
                    $edit_term_link = admin_url("term.php?taxonomy=$taxonomy&tag_ID=$term_id");

                    // Generate the edit term link
                    $output .= '<div class="link-cont"><a target="_blank" class="smd-link term-link" href="' . $edit_term_link . '">' . $object_type . ' ID:' . $term_id . '</a></div>';
                }
            }
            $output .= '<div class="full-warning"><div class="delete-warning">IMAGE WARNING - </div><div class="warning-info">This image can not be removed.<br />Please remove the image from the post(s) or
    term(s) where it is being used by using the "Linked Articles" above</div></div>';
        }

        // Remove trailing comma and space
        $output = rtrim($output, ', ');

        echo $output;
    }
}
add_action('manage_media_custom_column', 'populate_attached_objects_column', 10, 2);



// Retrieve attached objects (posts or terms) for the media attachment

function get_attached_objects_alt($attachment_id)
{
    $attached_objects = array();

    // Check if attachment is associated with a post as a featured image
    $post_parents = get_posts(array(
    'meta_key' => '_thumbnail_id',
    'meta_value' => $attachment_id,
    'post_type' => array('post', 'page'),
    'post_status' => 'any',
    'fields' => 'ids',
    ));

    if ($post_parents) {
        foreach ($post_parents as $parent_id) {
            $attached_objects[] = get_post($parent_id);
        }
    }

    // Check if attachment is included in post content
    $post_containing_attachments = get_posts(array(
    's' => $attachment_id,
    'post_type' => array('post', 'page'),
    'post_status' => 'any',
    'fields' => 'ids',
    ));

    if ($post_containing_attachments) {
        foreach ($post_containing_attachments as $post_id) {
            $attached_objects[] = get_post($post_id);
        }
    }

    global $wpdb;

    $term_ids = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT term_id FROM $wpdb->termmeta WHERE meta_key = 'taxonomy_image_id' AND meta_value = %s",
            $attachment_id
        )
    );

    if ($term_ids) {
        foreach ($term_ids as $term_id) {
            $term = get_term($term_id);
            $term->object_type = 'term';
            $attached_objects[] = $term;
        }
    }

    return $attached_objects;
}
