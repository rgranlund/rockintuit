<?php

// Register the REST API endpoint
add_action('rest_api_init', 'register_delete_image_endpoint');

function register_delete_image_endpoint()
{
    register_rest_route('assignment/v1', '/image/delete/(?P<id>\d+)', array(
        'methods'  => 'DELETE',
        'callback' => 'delete_image',
        'args'     => array(
            'id' => array(
                'validate_callback' => function ($param, $request, $key) {
                    $url = $request->get_url_params();
                    $url_parts = explode('/', $url['id']);
                    $id = end($url_parts);
                    return is_numeric($id);
                },
                'required'    => true,
                'description' => 'This is the ID of the Deleted Image'
            )
        )
    ));

}


//This is the Callback function to delete an image
function delete_image($request)
{
    var_dump($request);
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        return new WP_Error('wrong_method', 'HTTP method not allowed.', array('status' => 405));
    }
    $image_id = $request->get_param('id');

    // Check if the image is attached to any posts or terms
    $attached_posts = get_posts(array(
        'post_type' => 'any',
        'post_status' => 'any',
        'meta_query' => array(
            array(
                'key' => '_thumbnail_id',
                'value' => $image_id,
                'compare' => '='
            )
        )
    ));

    $attached_terms = get_object_term_cache($image_id, 'attachment');

    // If the image is attached to any posts or terms, return a response stating that deletion failed
    if (!empty($attached_posts) || !empty($attached_terms)) {
        return new WP_Error('image_attached', 'The image is attached to one or more posts or terms and cannot be deleted.', array('status' => 400));
    }

    // If the image is not attached to any posts or terms, delete it and return a response stating that deletion was successful
    $deleted = wp_delete_attachment($image_id, true);

    if ($deleted === false) {
        return new WP_Error('image_delete_failed', 'The image could not be deleted.', array('status' => 500));
    }

    return array('Success: The image ID: '.$image_id.' has been deleted.' => true, 'status' => 200);
}