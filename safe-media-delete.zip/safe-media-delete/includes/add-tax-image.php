<?php
function enqueue_taxonomy_image_scripts()
{
    if (isset($_GET['taxonomy']) && !empty($_GET['taxonomy'])) {
        $taxonomy = $_GET['taxonomy'];
        $screen = get_current_screen();

        // Check if the current screen is a taxonomy edit screen
        if ($screen->base === 'edit-tags' && $screen->taxonomy === $taxonomy) {
            wp_enqueue_media();
        }
    }
}
add_action('admin_enqueue_scripts', 'enqueue_taxonomy_image_scripts');


function add_taxonomy_custom_fields($term)
{
    ob_start();
    $image_id = "";
    $image_url  = "";
    if (isset($term) && is_object($term)) {
        $image_id = get_term_meta($term->term_id, 'taxonomy_image_id', true);
        $image_url = wp_get_attachment_image_src($image_id, 'thumbnail');
    }

    ?>
<tr class="form-field">
    <th scope="row" valign="top">
        <label for="taxonomy_image"
            class="tax-label-title"><?php esc_html_e('Taxonomy Image', 'safe-media-delete'); ?></label>
    </th>
    <td>
        <input type="hidden" name="taxonomy_image_id" id="taxonomy_image_id"
            value="<?php echo esc_attr($image_id); ?>" />
        <button id="taxonomy_image_button"
            class="button"><?php esc_html_e('Select Image', 'safe-media-delete'); ?></button>
        <button id="remove_taxonomy_image_button" class="button"
            style="display: <?php echo($image_id ? 'inline-block' : 'none'); ?>"><?php esc_html_e('Remove Image', 'safe-media-delete'); ?></button>
        <div id="taxonomy_image_preview">
            <?php if ($image_id) { ?><img
                src="<?php echo esc_url(wp_get_attachment_image_url($image_id, 'thumbnail')); ?>"
                alt="<?php esc_attr_e('Taxonomy Image', 'safe-media-delete'); ?>"
                style="max-width: 150px; height: auto;" /><?php } ?>
        </div>
        <p class="description">
            <?php esc_html_e('Select or upload an image for the taxonomy term.', 'safe-media-delete'); ?>
        </p>
    </td>
</tr>
<script>
    jQuery(document).ready(function($) {
        // Media uploader
        var mediaUploader;

        // Image button click event
        $(document).on('click', '#taxonomy_image_button', function(e) {
            e.preventDefault();

            // If the media uploader exists, open it
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }

            // Create the media uploader
            mediaUploader = wp.media({
                title: '<?php esc_attr_e('Select Image', 'safe-media-delete'); ?>',
                button: {
                    text: '<?php esc_attr_e('Select', 'safe-media-delete'); ?>'
                },
                multiple: false
            });

            // Image selection event
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();

                // Set the image ID and preview
                $('#taxonomy_image_id').val(attachment.id);
                $('#taxonomy_image_preview').html('<img src="' + attachment.url +
                    '" alt="<?php esc_attr_e('Taxonomy Image', 'safe-media-delete'); ?>" style="max-width: 150px; height: auto;" />'
                );

                // Show remove image button
                $('#remove_taxonomy_image_button').show();
            });

            // Open the media uploader
            mediaUploader.open();
        });

        // Remove image button click event
        $(document).on('click', '#remove_taxonomy_image_button', function(e) {
            e.preventDefault();

            // Remove the image ID and preview
            $('#taxonomy_image_id').val('');
            $('#taxonomy_image_preview').html('');

            // Hide remove image button
            $('#remove_taxonomy_image_button').hide();
        });
    });
</script>

<?php
 $output = ob_get_clean();
    echo $output;
}



function save_taxonomy_custom_fields($term_id)
{
    if (isset($_POST['taxonomy_image_id'])) {
        $image_id = intval($_POST['taxonomy_image_id']);
        update_term_meta($term_id, 'taxonomy_image_id', $image_id);
    }
}

function add_custom_fields_to_taxonomies()
{
    $taxonomies = get_taxonomies('', 'names');

    foreach ($taxonomies as $taxonomy) {
        add_action("{$taxonomy}_add_form_fields", 'add_taxonomy_custom_fields');
        add_action("{$taxonomy}_edit_form_fields", 'add_taxonomy_custom_fields');
        add_action("create_{$taxonomy}", 'save_taxonomy_custom_fields');
        add_action("edited_{$taxonomy}", 'save_taxonomy_custom_fields');
    }
}
add_action('admin_init', 'add_custom_fields_to_taxonomies');


// Retrieve the term ID where the image is saved
function get_term_id_of_taxonomy_image($image_id)
{
    $terms = get_terms(array(
        'meta_key' => 'taxonomy_image_id',
        'meta_value' => $image_id,
        'hide_empty' => false,
    ));

    if ($terms && !is_wp_error($terms)) {
        // Assuming the image ID is unique to a single term
        $term = reset($terms); // Get the first term
        $term_id = $term->term_id;

        return $term_id;
    }

    // If no term is found with the specified image ID
    return false;
}
