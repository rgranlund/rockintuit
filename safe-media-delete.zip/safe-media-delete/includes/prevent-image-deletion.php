<?php
// Modify the pre_delete_attachment_defaults filter
function modify_pre_delete_attachment_defaults($delete, $post, $force_delete) {
    // Update the $delete variable according to your website requirements
    $attachment_id = $post->ID;
    $output = generate_custom_content($attachment_id);
    if ($output) {
        // Execute a custom script to manipulate the DOM
        $delete = false;
    } else {
        $delete = true;
    }

    return $delete;
}
add_filter("pre_delete_attachment", "modify_pre_delete_attachment_defaults", 10, 3);

?>