<?php

// Add custom content to the media library edit screen for a specific attachment
function generate_custom_content($attachment_id)
{
    $attached_objects = get_attached_objects_alt($attachment_id);
    $output = '';
    if($attached_objects) {
        foreach ($attached_objects as $object) {
            $object_type = '';

            if ($object->post_type) {
                $p_type = $object->post_type;
                if ($p_type == "post") {
                    $object_type = 'Post';
                } elseif ($p_type == "page") {
                    $object_type = 'Page';
                }

                $output .= '<div class="link-cont"><a target="_blank" class="smd-link '.$p_type.'-link" href="' . get_edit_post_link($object->ID) . '">' . $object_type . ' ID:' . $object->ID . '</a></div>';
            } elseif ($object->taxonomy) {
                $object_type = 'Term';
                $term_id = $object->term_id;

                $taxonomy = $object->taxonomy;
                $edit_term_link = admin_url("term.php?taxonomy=$taxonomy&tag_ID=$term_id");

                // Generate the edit term link
                $output .= '<div class="link-cont"><a target="_blank" class="smd-link term-link" href="' . $edit_term_link . '">' . $object_type . ' ID:' . $term_id . '</a></div>';
            }
        }
        $output .= '<div class="full-warning"><div class="delete-warning">IMAGE WARNING - </div><div class="warning-info">This image can not be removed.<br />Please remove the image from the post(s) or
    term(s) where it is being used by using the "Linked Articles" above</div></div>';
    }

    return $output;
}

function add_custom_content_to_attachment_details($form_fields, $post)
{
    // Get attached objects
    $attachment_id = $post->ID;
    $output = generate_custom_content($attachment_id);


    if($output) {
        // Append the custom content to the existing form fields
        $form_fields['custom_content'] = array(
            'label' => __('Linked Articles'),
            'input' => 'html',
           'html' => $output,
        );
    }

    return $form_fields;
}
add_filter('attachment_fields_to_edit', 'add_custom_content_to_attachment_details', 10, 2);



function image_attachment_meta_box()
{
    add_meta_box(
        'image_attachment_meta_box',
        'Image Attachment Details',
        'image_attachment_meta_box_callback',
        'attachment',
        'side',
        'high'
    );
}

function image_attachment_meta_box_callback($post)
{
    $attachment_id = $post->ID;
    // Check if the attachment is an image
    if (wp_attachment_is_image($attachment_id)) {
        // Add your custom content here
        $output ="";
        $output .= "Linked Articles:";
        $output = generate_custom_content($attachment_id);
        if($output) {
            echo '<b>Linked Articles:</b><br />'. $output;
        } else {
            echo '<b>No Linked Articles</b>';
        }
    }
}

add_action('add_meta_boxes_attachment', 'image_attachment_meta_box');
