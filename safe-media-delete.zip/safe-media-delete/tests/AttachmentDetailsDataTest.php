<?php

require_once dirname(__FILE__) . '/../../../../wp-load.php';
require_once __DIR__ . '/../includes/attachment-details-data.php';



class AttachmentDetailsDataTest extends \PHPUnit\Framework\TestCase
{
    public function test_generate_custom_content()
    {
        // Arrange
        $attachment_id = 1;

        // Act
        $result = generate_custom_content($attachment_id);

        // Assert
        $this->assertIsString($result);
        $this->assertStringContainsString('<a', $result);
        $this->assertStringContainsString('class="smd-link"', $result);
        $this->assertStringContainsString('target="_blank"', $result);
        $this->assertStringContainsString('href="', $result);
        $this->assertStringContainsString('ID:', $result);
        $this->assertStringContainsString('</a>', $result);
        $this->assertStringContainsString('<div class="full-warning">', $result);
        $this->assertStringContainsString('<div class="delete-warning">', $result);
        $this->assertStringContainsString('IMAGE WARNING', $result);
        $this->assertStringContainsString('This image can not be removed.', $result);
        $this->assertStringContainsString('Please remove the image from the post(s) or', $result);
        $this->assertStringContainsString('term(s) where it is being used by using the "Linked Articles" above', $result);
    }



}