<?php

require_once dirname(__FILE__) . '/../../../../wp-load.php';
require_once __DIR__ . '/../includes/add-tax-image.php';

class Term
{
    public $term_id;

    public function __construct($id)
    {
        $this->term_id = $id;
    }

    public function __isset($name)
    {
        return false;
    }
}

class AddTaxImageTest extends \PHPUnit\Framework\TestCase
{
    public function test_add_taxonomy_custom_fields()
    {
        // Create a term object
        $term = new Term(1);

        // Call the function
        ob_start();
        add_taxonomy_custom_fields($term);
        $output = ob_get_clean();

        // Assert that the output contains the expected HTML elements
        $this->assertStringContainsString('<input type="hidden" name="taxonomy_image_id"', $output);
        $this->assertStringContainsString('<input type="button" id="taxonomy_image_button"', $output);
        $this->assertStringContainsString('<div id="taxonomy_image_preview">', $output);
        $this->assertStringContainsString('<p class="description">', $output);
    }
}
