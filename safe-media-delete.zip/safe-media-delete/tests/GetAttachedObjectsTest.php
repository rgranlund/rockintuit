<?php

require_once dirname(__FILE__) . '/../../../../wp-load.php';
require_once __DIR__ . '/../includes/media-column-data.php';


use PHPUnit\Framework\TestCase;

class GetAttachedObjectsTest extends TestCase
{
    public function test_get_attached_objects_alt()
    {
        $attachment_id = 123;

        // Call the function and assert the result
        //  $result = get_attached_objects_alt($attachment_id);
        //  $this->assertEquals(array(), $result);

        // Add more test cases here

        // Call the function and get the result
        $result = get_attached_objects_alt($attachment_id);

        // Assert that the result is an array
        $this->assertIsArray($result);


        // Assert that each item in the result is an object
        foreach ($result as $item) {
            $this->assertIsObject($item);
        }

    }
}
