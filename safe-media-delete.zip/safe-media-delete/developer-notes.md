This plugin supplies the following functiuonality:

1.  Ability to add an Image to a Term
2.  This plugin disables the ability to permanently delete an image from the Media Library if the image is associated with a Page, Post or Term.
3.  Lists all of the Pages, Posts and Terms an image is associated with on the Media Library page.
4.  Lists all of the Pages, Posts and Terms an image is associated with on the Attachment Details page.
5.  Along with the Image details, a link to all corresponding Post, Page or Terms are supplied and color coded for deferentiation.The files in the

The files in the /includes directory contain the following functionality

1. add-tax-image.php
   Add an image to a Term
   Save and/or update the termmeta

2. attachment-details-data.php
   Adds additional content to the Attachment Details
   Adds links to all of the pages, posts or terms an image is associated with

3. image-api.php
   Adds an api endpoint to display all of the pages, posts and terms and image is associated with

4. image-deletion-api.php
   Adds an api endpoint to delete an image that is not associated with a page, post or term

5. media-column-data.php
   Adds a column to the Media Library
   Adds all of the Attached Object data to the column and links to all of the associated post, pages and terms.

6. prevent-image-deletion.php
   this file prevents an image from being deleted if an image is assciated with a post, page or term

The /tests folder contains

1.  AddTaxImageTest.php
    This test the ability to add and image to taxonomy and save

2.  AttachmentDetailsDataTest.php
    This test the functionality to attach data to the Media Libray Attached Object Column that has been created.

3.  GetAttachedObjectsTest.php
    This tests the functionality of adding object data to the attachment details

Edge Cases that have not been addressed

1. Images that are added to a post or page via a custom fields
2. The requirments did not include sending a response for no image found with the image api
