<?php
/*
Plugin Name: Safe Media Delete
Description: Prevents deletion of mediaa files currenttly in use.
Version: 1.0.0
Author: Robert Granlund
Author URI: https://rockintuit.com
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: safe-media-delete
*/


define('SMD', plugin_dir_path(__FILE__));


//  Enqueue The Safe Media Delete CSS
function safe_delete_enqueue_styles()
{
    wp_enqueue_style('safe-media-styles', plugins_url('css/style.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'safe_delete_enqueue_styles');




// Add the form to the term edit page and display the image
// Add custom fields to the taxonomy term edit page
require_once(plugin_dir_path(__FILE__) . 'includes/add-tax-image.php');


/*
Add Column and data to the Media Library
*/
require_once(plugin_dir_path(__FILE__) . 'includes/media-column-data.php');


/*
Add Term and Post info onto the Attachment Details Page
*/
require_once(plugin_dir_path(__FILE__) . 'includes/attachment-details-data.php');

/*
Function to prevent deletion of a media file if it is a featured image.
delete_attachment is the function to hook into
Prevent deletion of media if it is used as a Featured Image
*/
require_once(plugin_dir_path(__FILE__) . 'includes/prevent-image-deletion.php');

/*
Add Image API Functionality
*/
require_once(plugin_dir_path(__FILE__) . 'includes/image-api.php');


/*
Add Image Deletion API Functionality
*/
require_once(plugin_dir_path(__FILE__) . 'includes/image-deletion-api.php');
